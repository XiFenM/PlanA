"""用本地 HF Transformers CPU FP32 参考校验 vLLM 的短生成结果。

本模块不下载权重；调用方负责 pinned snapshot 与文件哈希核验。
HTTP 成功、非空文本或 CPU 参考耗时均不是本模块的正确性/性能证据。
"""

from __future__ import annotations

import json
import math
import os
from pathlib import Path
import tempfile
from typing import Any


MODEL_ID = "Qwen/Qwen2.5-1.5B-Instruct"
MODEL_REVISION = "989aa7980e4cf806f80c7fef2b1adb7bc71aa306"
EXPECTED_GENERATED_TOKENS = 8
MAX_LOGPROB_ABS_DIFF = 0.25
MAX_GREEDY_LOGPROB_GAP = 0.10
BOUNDARY_EPSILON = 1e-12


class CorrectnessError(RuntimeError):
    """校验未通过或报告未保存；保存失败时 report 保留原错误和 persistence_error。"""

    def __init__(self, message: str, report: dict[str, Any]):
        super().__init__(message)
        self.report = report


def _positive_int(value: Any, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError(f"{name} 必须是正整数")
    return value


def _logprob(value: Any, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} 必须是有限数值")
    result = float(value)
    if not math.isfinite(result) or result > 0:
        raise ValueError(f"{name} 必须是有限且不大于 0 的 log probability")
    return result


def prediction_positions(prompt_length: int, generated_length: int) -> list[int]:
    """第 j 个生成 token 由 prompt_length - 1 + j 位置的 hidden state 预测。"""
    _positive_int(prompt_length, "prompt_length")
    _positive_int(generated_length, "generated_length")
    return list(range(prompt_length - 1, prompt_length + generated_length - 1))


def validate_records(
    records: Any,
    vocab_size: int,
    *,
    expected_generated_tokens: int | None = None,
) -> list[dict[str, Any]]:
    """在模型执行前验证完整批次，返回副本，不修改 HTTP 原始记录。"""
    _positive_int(vocab_size, "vocab_size")
    if expected_generated_tokens is not None:
        _positive_int(expected_generated_tokens, "expected_generated_tokens")
    if not isinstance(records, list) or not records:
        raise ValueError("records 必须是非空列表")
    normalized = []
    request_ids: set[str] = set()
    for case_index, record in enumerate(records):
        if not isinstance(record, dict):
            raise ValueError(f"records[{case_index}] 必须是对象")
        request_id = record.get("request_id")
        if not isinstance(request_id, str) or not request_id.strip():
            raise ValueError(f"records[{case_index}].request_id 必须是非空字符串")
        if request_id in request_ids:
            raise ValueError(f"request_id 重复: {request_id}")
        request_ids.add(request_id)
        clean: dict[str, Any] = {"request_id": request_id}
        for field in ("prompt_token_ids", "token_ids"):
            values = record.get(field)
            if not isinstance(values, list) or not values:
                raise ValueError(f"{request_id}.{field} 必须是非空列表")
            for index, token_id in enumerate(values):
                if (
                    isinstance(token_id, bool)
                    or not isinstance(token_id, int)
                    or not 0 <= token_id < vocab_size
                ):
                    raise ValueError(
                        f"{request_id}.{field}[{index}] 必须是 [0, {vocab_size}) 内整数"
                    )
            clean[field] = list(values)
        token_logprobs = record.get("token_logprobs")
        if not isinstance(token_logprobs, list):
            raise ValueError(f"{request_id}.token_logprobs 必须是列表")
        if len(token_logprobs) != len(clean["token_ids"]):
            raise ValueError(f"{request_id} 的 token_ids 与 token_logprobs 长度不一致")
        if (
            expected_generated_tokens is not None
            and len(clean["token_ids"]) != expected_generated_tokens
        ):
            raise ValueError(f"{request_id} 必须恰好生成 {expected_generated_tokens} 个 token")
        clean["token_logprobs"] = [
            _logprob(value, f"{request_id}.token_logprobs[{index}]")
            for index, value in enumerate(token_logprobs)
        ]
        normalized.append(clean)
    return normalized


def _within_limit(value: float, limit: float) -> bool:
    # 只消除二进制浮点在十进制边界上的舍入误差，不放宽数值误差预算。
    return value <= limit or math.isclose(value, limit, rel_tol=0, abs_tol=BOUNDARY_EPSILON)


def score_reference_position(
    *,
    token_id: int,
    server_logprob: float,
    reference_logprob: float,
    reference_top1_id: int,
    reference_top1_logprob: float,
) -> dict[str, Any]:
    """分别检查概率一致性与贪心选择；不同 token 仅在近似平局时允许通过。"""
    for name, value in (("token_id", token_id), ("reference_top1_id", reference_top1_id)):
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError(f"{name} 必须是非负整数")
    server_logprob = _logprob(server_logprob, "server_logprob")
    reference_logprob = _logprob(reference_logprob, "reference_logprob")
    reference_top1_logprob = _logprob(reference_top1_logprob, "reference_top1_logprob")
    gap = reference_top1_logprob - reference_logprob
    if gap < 0:
        raise ValueError("reference_top1_logprob 不能小于候选 token 的参考 logprob")
    if token_id == reference_top1_id and gap != 0:
        raise ValueError("相同参考 token 的 logprob 必须相等")
    abs_diff = abs(server_logprob - reference_logprob)
    probability_passed = _within_limit(abs_diff, MAX_LOGPROB_ABS_DIFF)
    greedy_passed = _within_limit(gap, MAX_GREEDY_LOGPROB_GAP)
    return {
        "token_id": token_id,
        "server_logprob": server_logprob,
        "reference_logprob": reference_logprob,
        "reference_top1_id": reference_top1_id,
        "reference_top1_logprob": reference_top1_logprob,
        "logprob_abs_diff": abs_diff,
        "greedy_logprob_gap": gap,
        "exact_top1_match": token_id == reference_top1_id,
        "probability_passed": probability_passed,
        "greedy_passed": greedy_passed,
        "passed": probability_passed and greedy_passed,
    }


def _evaluate_case(model: Any, torch: Any, record: dict[str, Any]) -> dict[str, Any]:
    prompt = record["prompt_token_ids"]
    generated = record["token_ids"]
    positions = prediction_positions(len(prompt), len(generated))
    # Teacher forcing 使用服务器实际生成的前缀；最后一个待预测 token 不进入输入。
    input_ids = torch.tensor([prompt + generated[:-1]], dtype=torch.long, device="cpu")
    with torch.inference_mode():
        output = model.model(
            input_ids=input_ids,
            use_cache=False,
            output_hidden_states=False,
            return_dict=True,
        )
        # 仅对最后 G 个 hidden states 投影到词表，避免完整 prompt 的 [L, V] logits。
        hidden = output.last_hidden_state[:, positions[0] : positions[-1] + 1, :]
        if hidden.shape[1] != len(generated):
            raise ValueError("参考 hidden-state 位置数量不匹配")
        logits = model.lm_head(hidden).float()
        if logits.shape != (1, len(generated), model.config.vocab_size):
            raise ValueError("参考 logits 形状不匹配")
        if not torch.isfinite(logits).all().item():
            raise ValueError("参考 logits 含非有限值")
        logprobs = torch.log_softmax(logits, dim=-1)[0]
        top1_ids = logprobs.argmax(dim=-1)
        case_positions = []
        for index, token_id in enumerate(generated):
            top1_id = int(top1_ids[index].item())
            score = score_reference_position(
                token_id=token_id,
                server_logprob=record["token_logprobs"][index],
                reference_logprob=float(logprobs[index, token_id].item()),
                reference_top1_id=top1_id,
                reference_top1_logprob=float(logprobs[index, top1_id].item()),
            )
            case_positions.append(
                {"generated_index": index, "input_position": positions[index], **score}
            )
    return {
        "request_id": record["request_id"],
        "prompt_token_ids": list(prompt),
        "token_ids": list(generated),
        "prompt_tokens": len(prompt),
        "generated_tokens": len(generated),
        "passed": all(position["passed"] for position in case_positions),
        "positions": case_positions,
    }


def _summarize(cases: list[dict[str, Any]], expected_cases: int) -> dict[str, Any]:
    positions = [position for case in cases for position in case["positions"]]
    return {
        "expected_cases": expected_cases,
        "evaluated_cases": len(cases),
        "passed_cases": sum(case["passed"] for case in cases),
        "failed_cases": sum(not case["passed"] for case in cases),
        "evaluated_positions": len(positions),
        "failed_positions": sum(not position["passed"] for position in positions),
        "max_logprob_abs_diff": max(
            (position["logprob_abs_diff"] for position in positions), default=None
        ),
        "max_greedy_logprob_gap": max(
            (position["greedy_logprob_gap"] for position in positions), default=None
        ),
    }


def _write_report(output_path: str | Path, report: dict[str, Any]) -> None:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=path.parent, prefix=f".{path.name}.",
            suffix=".tmp", delete=False,
        ) as stream:
            temporary_path = Path(stream.name)
            json.dump(report, stream, ensure_ascii=False, indent=2, allow_nan=False)
            stream.write("\n")
            stream.flush()
            os.fsync(stream.fileno())
        # 同目录的完整临时文件以 hard link 原子发布；目标存在时绝不替换。
        # 入口检查只提供早期报错，此操作仍防止检查之后的竞争写入。
        os.link(temporary_path, path)
    finally:
        if temporary_path is not None:
            try:
                temporary_path.unlink(missing_ok=True)
            except OSError:
                pass  # 临时文件清理不能掩盖序列化、发布或原始校验错误。


def _persist_report(output_path: str | Path, report: dict[str, Any]) -> Exception | None:
    """保留持久化错误供调用方附加，避免覆盖原始校验失败原因。"""
    try:
        _write_report(output_path, report)
    except Exception as error:
        report["persistence_error"] = {"type": type(error).__name__, "message": str(error)}
        return error
    return None


def evaluate_records(
    model_path: str | Path,
    records: list[dict[str, Any]],
    output_path: str | Path,
    *,
    threads: int = 8,
) -> dict[str, Any]:
    """成功时返回已保存报告；未通过时尝试保存报告，再抛出 CorrectnessError。

    依赖延迟导入，纯数据/评分测试无需安装 torch 或 transformers。只允许本地
    Qwen2ForCausalLM；固定短输出与阈值不可通过调用参数放宽。CPU 运行不计时。
    已有 output_path（包括悬空符号链接）在入口抛出 FileExistsError，绝不覆盖。
    """
    if os.path.lexists(output_path):
        raise FileExistsError(f"正确性报告已存在，拒绝覆盖: {output_path}")
    expected_cases = len(records) if isinstance(records, list) else 0
    report: dict[str, Any] = {
        "schema_version": 1,
        "status": "error",
        "passed": False,
        "expected_model_id": MODEL_ID,
        "expected_model_revision": MODEL_REVISION,
        "model_path": str(model_path),
        "weight_identity_scope": "调用方负责 pinned snapshot 与权重文件哈希核验",
        "reference": {
            "implementation": "HF Transformers Qwen2ForCausalLM",
            "device": "cpu",
            "dtype": "float32",
            "attention": "eager",
            "conditioning": "teacher forcing on actual server-generated prefix",
            "use_cache": False,
            "performance_measurement": False,
        },
        "thresholds": {
            "logprob_abs_diff_max_nats": MAX_LOGPROB_ABS_DIFF,
            "greedy_logprob_gap_max_nats": MAX_GREEDY_LOGPROB_GAP,
            "boundary_roundoff_epsilon": BOUNDARY_EPSILON,
            "all_positions_must_pass": True,
            "generated_tokens_per_case": EXPECTED_GENERATED_TOKENS,
        },
        "cases": [],
    }
    phase = "model_contract"
    try:
        _positive_int(threads, "threads")
        if threads > 8:
            raise ValueError("CPU 参考最多使用 8 个线程")
        local_path = Path(model_path).resolve()
        if not local_path.is_dir():
            raise ValueError("model_path 必须是已经下载并验证的本地模型目录")
        config = json.loads((local_path / "config.json").read_text(encoding="utf-8"))
        if (
            config.get("model_type") != "qwen2"
            or config.get("architectures") != ["Qwen2ForCausalLM"]
        ):
            raise ValueError("参考仅支持 Qwen2ForCausalLM / qwen2 架构")
        vocab_size = _positive_int(config.get("vocab_size"), "config.vocab_size")
        phase = "records"
        clean_records = validate_records(
            records, vocab_size, expected_generated_tokens=EXPECTED_GENERATED_TOKENS
        )
        phase = "reference_load"
        import torch
        import transformers
        from transformers import AutoModelForCausalLM

        torch.set_num_threads(threads)
        if torch.get_num_interop_threads() != 1:
            # 并行工作已开始时 PyTorch 会拒绝修改；此时失败，不静默突破资源上限。
            torch.set_num_interop_threads(1)
        report["reference"].update(
            threads=threads, interop_threads=torch.get_num_interop_threads(),
            torch_version=torch.__version__, transformers_version=transformers.__version__,
        )
        model = AutoModelForCausalLM.from_pretrained(
            str(local_path), local_files_only=True, trust_remote_code=False,
            torch_dtype=torch.float32, attn_implementation="eager",
        )
        model.eval()
        if (
            type(model).__name__ != "Qwen2ForCausalLM"
            or model.config.model_type != "qwen2"
            or model.config.vocab_size != vocab_size
            or model.config._attn_implementation != "eager"
            or not hasattr(model, "model")
            or not hasattr(model, "lm_head")
        ):
            raise ValueError("已加载参考模型与固定架构/配置不一致")
        if any(
            parameter.device.type != "cpu"
            or (parameter.is_floating_point() and parameter.dtype != torch.float32)
            for parameter in model.parameters()
        ):
            raise ValueError("参考模型必须完整位于 CPU 并使用 FP32 参数")
        phase = "reference_evaluation"
        for record in clean_records:
            report["cases"].append(_evaluate_case(model, torch, record))
        report["passed"] = all(case["passed"] for case in report["cases"])
        report["status"] = "passed" if report["passed"] else "failed"
    except Exception as error:
        report["error"] = {
            "phase": phase, "type": type(error).__name__, "message": str(error)
        }
        report["summary"] = _summarize(report["cases"], expected_cases)
        persistence_error = _persist_report(output_path, report)
        message = f"独立正确性校验无法完成 ({phase}): {error}"
        if persistence_error is not None:
            message += f"；报告保存也失败: {persistence_error}"
        raise CorrectnessError(message, report) from error
    report["summary"] = _summarize(report["cases"], expected_cases)
    persistence_error = _persist_report(output_path, report)
    if not report["passed"]:
        message = "独立正确性校验未通过；禁止继续 benchmark"
        if persistence_error is not None:
            message += f"；报告保存也失败: {persistence_error}"
        raise CorrectnessError(message, report) from persistence_error
    if persistence_error is not None:
        report.update(status="error", passed=False, reference_evaluation_passed=True)
        report["error"] = {"phase": "report_write", **report["persistence_error"]}
        raise CorrectnessError(
            f"参考结果通过，但报告保存失败；禁止继续 benchmark: {persistence_error}", report
        ) from persistence_error
    return report
